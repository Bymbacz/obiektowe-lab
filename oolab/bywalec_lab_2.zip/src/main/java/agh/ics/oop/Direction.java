package agh.ics.oop;
enum Direction {
    FORWARD,
    BACKWARD,
    RIGHT,
    LEFT
}